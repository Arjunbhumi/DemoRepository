package com.gl.hcl.miniproject1;

import java.sql.SQLException;
import java.util.Scanner;

public class AbhiruchiResturent {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws SQLException, ExceptionHandling {
		while (true) {
			System.out.println("WElCOME TO Abhiruchi RESTAURENT...");
			System.out.println("0.Exit");
			System.out.println("1.admin");
			System.out.println("2.user");
			int ch = sc.nextInt();
			switch (ch) {
			case 0:
				System.out.println("You are Choosen the Exit option...");
				System.exit(0);
				break;
			case 1:
				while (true) {
					System.out.println("You are choosen the admin option");
					System.out.println("Enter the choice: ");
					System.out.println("1.Register");
					System.out.println("2.Login");
					int i = sc.nextInt();
					switch (i) {
					case 0:
						System.out.println("You are Choosen the Exit option...");
						System.exit(0);
						break;
					case 1:
						System.out.println("You are choosen the admin registration");
						AdminCRUDOperation.adminRegistration();
						break;
					case 2:

						System.out.println("You are choosen the admin login");
						AdminCRUDOperation.adminLogin();
						while (true) {
							System.out.println("Enter the choice: ");
							System.out.println("0.Exit");
							System.out.println("1.insert items");
							System.out.println("2.update items");
							System.out.println("3.delete items");
							System.out.println("4.diplay items");
							System.out.println("5.display today bill");
							System.out.println("6.display monthly bill");
							int k = sc.nextInt();
							switch (k) {
							case 0:
								System.out.println("You are Choosen the Exit option...");
								System.exit(0);
								break;
							case 1:
								System.out.println("insert items into the restaurent menu");
								AdminCRUDOperation.insertItems();
								break;
							case 2:
								System.out.println("update items into the restaurent menu");
								AdminCRUDOperation.updateItems();
								break;
							case 3:
								System.out.println("delete items into the restaurent menu");
								AdminCRUDOperation.deleteItems();
								break;
							case 4:
								System.out.println("display items from the restaurent menu");
								AdminCRUDOperation.selectItems();
								break;
							case 5:
								System.out.println("display today bill");
								AdminCRUDOperation.todaySaleBill();
								break;
							case 6:
								System.out.println("display today bill");
								AdminCRUDOperation.monthlyBill();
								break;
							default:
								System.out.println("you are selected wrong option");
								break;
							}

							System.out.println("do you want to continue the admin crud operations..yes/no");
							String in1 = sc.next();
							if (in1.equalsIgnoreCase("no")) {
								break;
							}
						}
					}
					System.out.println("do you want to continue the admin process ...yes/no");
					String in2 = sc.next();
					if (in2.equalsIgnoreCase("no")) {
						break;
					}
				}
			case 2:
				while (true) {
					System.out.println("You are choosen the user option");
					System.out.println("Enter the choice: ");
					System.out.println("1.Register");
					System.out.println("2.Login");
					int j = sc.nextInt();
					switch (j) {
					case 0:
						System.out.println("You are Choosen the Exit option...");
						System.exit(0);
						break;
					case 1:
						System.out.println("You are choosen the user registration");
						UserOperation.userRegistration();
						break;
					case 2:
						System.out.println("You are choosen the user login");
						UserOperation.userLogin();
						while (true) {
							System.out.println("Enter the choice: ");
							System.out.println("1.orders");
							System.out.println("2.bill screen");
							int m = sc.nextInt();
							switch (m) {
							case 0:
								System.out.println("You are Choosen the Exit option...");
								System.exit(0);
								break;
							case 1:
								System.out.println("you are choosen the orders option");
								UserOperation.order();
								break;
							case 2:
								System.out.println("you are choosen the bill screen option");
								UserOperation.billScreen();
								break;
							default:
								System.out.println("You are choosen wrong option");
								break;
							}
							System.out.println("do you want to continue the  user...yes/no");
							String in1 = sc.next();
							if (in1.equalsIgnoreCase("no")) {
								break;
							}
						}
					}
					System.out.println("do you want to continue the user...yes/no");
					String in1 = sc.next();
					if (in1.equalsIgnoreCase("no")) {
						break;

					}
				}

				break;
			default:
				System.out.println("You are choosen wrong option");
				break;
			}
			// admin or user
			System.out.println("do you want to continue the admin or user...yes/no");
			String in1 = sc.next();
			if (in1.equalsIgnoreCase("no")) {
				break;
			}
		}

	}
}
