package com.gl.hcl.miniproject1;

@SuppressWarnings("serial")
/**
 * here we are taking one custom class to handle the exception part and then we
 * need to extend the super class ,ie, exception class to access other kind of
 * exceptions
 * 
 *
 */

public class ExceptionHandling extends Exception {

	// here we are creating the contructor for the class and passing one string
	// argument as parameter
	ExceptionHandling(String s) {
		// here calling the super method
		super(s);
	}

}
