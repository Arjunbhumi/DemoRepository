package com.gl.hcl.miniproject1;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AdminCRUDOperation {
	static PreparedStatement pst = null;
	static ResultSet rst = null;
	static int item_no;
	static String item_name;
	static int item_price;
	static int i;
	static Scanner sc = new Scanner(System.in);
	static String adminUserName;
	static String adminPassword;
	static int adminId;
	static String adminEmailId;

	public static void adminRegistration() {

		System.out.println("Enter the user name: ");
		adminUserName = sc.next();

		System.out.println("Enter the user Id: ");
		adminId = sc.nextInt();

		System.out.println("Enter the emailId: ");
		adminEmailId = sc.next();

		System.out.println("Enter the password: ");
		adminPassword = sc.next();

	}

	public static void adminLogin() throws ExceptionHandling {
		System.out.println("Enter the user name: ");
		String auname = sc.next();
		System.out.println("Enter the password: ");
		String apass = sc.next();
		if (auname.equalsIgnoreCase(adminUserName) && apass.equalsIgnoreCase(adminPassword)) {
			System.out.println("login successful...");
		} else {
			throw new ExceptionHandling("incorrecct username or password...");
		}

	}

	public static void insertItems() throws SQLException {
		System.out.println("Enter the item number: ");
		item_no = sc.nextInt();
		System.out.println("Enter the item name: ");
		item_name = sc.next();
		System.out.println("Enter the item price: ");
		item_price = sc.nextInt();
		String addItem = "insert into ItemMenu values(?,?,?)";
		pst = JdbcConnection.getConnection().prepareStatement(addItem);
		pst.setInt(1, item_no);
		pst.setString(2, item_name);
		pst.setInt(3, item_price);
		i = pst.executeUpdate();
		if (i > 0) {
			System.out.println("Item is inserted Successfully....");
		} else {
			System.out.println("Item is not inserted...");
		}

	}

	public static void updateItems() throws SQLException {
		System.out.println("Enter the item number: ");
		item_no = sc.nextInt();
		String selItem = "select * from ItemMenu where item_no=?";
		pst = JdbcConnection.getConnection().prepareStatement(selItem);
		pst.setInt(1, item_no);
		rst = pst.executeQuery();
		if (rst.next()) {
			System.out.println("select which field you want to update...");
			System.out.println("0.exit");
			System.out.println("1.all fields...");
			System.out.println("2.item name");
			System.out.println("3.item price");
			int p = sc.nextInt();
			switch (p) {
			case 0:
				System.out.println("You are Choosen the Exit option...");
				System.exit(0);
				break;
			case 1:
				System.out.println("you are choosen the all field change option");
				System.out.println("Enter the item name: ");
				item_name = sc.next();
				System.out.println("Enter the item price: ");
				item_price = sc.nextInt();
				String allChange = "update ItemMenu set item_price=?,item_name=? where item_no=?";
				pst = JdbcConnection.getConnection().prepareStatement(allChange);
				pst.setInt(1, item_price);
				pst.setString(2, item_name);
				pst.setInt(3, item_no);
				int x = pst.executeUpdate();
				if (x > 0) {
					System.out.println("item details are successfully updated...");
				} else {
					System.out.println("item details are not updated...");
				}
				break;
			case 2:
				System.out.println("you are choosen the item name change option");
				System.out.println("Enter the item name: ");
				item_name = sc.next();
				String nameChange = "update ItemMenu set item_name=? where item_no=?";
				pst = JdbcConnection.getConnection().prepareStatement(nameChange);
				pst.setString(1, item_name);
				pst.setInt(2, item_no);
				int y = pst.executeUpdate();
				if (y > 0) {
					System.out.println("item name is successfully updated...");
				} else {
					System.out.println("item name is not updated...");
				}
				break;
			case 3:
				System.out.println("you are choosen the item price change option");
				System.out.println("Enter the item price: ");
				item_price = sc.nextInt();
				String priceChange = "update ItemMenu set item_price=? where item_no=?";
				pst = JdbcConnection.getConnection().prepareStatement(priceChange);
				pst.setInt(1, item_price);
				pst.setInt(2, item_no);
				int z = pst.executeUpdate();
				if (z > 0) {
					System.out.println("item price is successfully updated...");
				} else {
					System.out.println("item price is not updated...");
				}
				break;

			}
		} else {
			System.out.println("item no is not found..");
		}

	}

	public static void deleteItems() throws SQLException {
		System.out.println("Enter the item number: ");
		item_no = sc.nextInt();
		String selItem = "select * from ItemMenu where item_no=?";
		pst = JdbcConnection.getConnection().prepareStatement(selItem);
		pst.setInt(1, item_no);
		rst = pst.executeQuery();
		if (rst.next()) {
			String delItem = "delete from ItemMenu where item_no=?";
			pst = JdbcConnection.getConnection().prepareStatement(delItem);
			pst.setInt(1, item_no);
			int k = pst.executeUpdate();
			if (k > 0) {
				System.out.println("item removed successfully...");
			} else {
				System.out.println("item is not removed...");

			}
		} else {
			System.out.println("item is not found...");
		}

	}

	public static void selectItems() throws SQLException {

		String selItem = "select * from ItemMenu";
		pst = JdbcConnection.getConnection().prepareStatement(selItem);

		rst = pst.executeQuery();
		System.out.println("ItemNo\tItemName\tItemPrice");
		while (rst.next()) {
			System.out.println(rst.getInt(1) + "\t" + rst.getString(2) + "\t\t" + rst.getInt(3));
		}

	}

	public static void todaySaleBill() throws SQLException {

		String totalSaleBill = "select * from order_table where ordered_date=?";
		pst = JdbcConnection.getConnection().prepareStatement(totalSaleBill);
		pst.setDate(1, DataClass.localDateTimeApi());
		rst = pst.executeQuery();
		System.out.println("ItemNo\tItemName\tItemPrice\tTotalAmount");
		while (rst.next()) {
			System.out
					.println(rst.getInt(1) + "\t" + rst.getString(2) + "\t\t" + rst.getInt(3) + "\t\t" + rst.getInt(4));
		}
		String totalCollection = "select sum(totalamt) from order_table where ordered_date=?";
		pst = JdbcConnection.getConnection().prepareStatement(totalCollection);
		pst.setDate(1, DataClass.localDateTimeApi());
		rst = pst.executeQuery();
		rst.next();
		int amt = rst.getInt(1);
		System.out.println("TOTAL TODAY COLLECTION IS: " + amt + "Rs");

	}

	public static void monthlyBill() throws SQLException {
		System.out.println("Enter month starting date");
		String from = sc.next();
		System.out.println("Enter month ending date");
		String end = sc.next();
		String mothlyBill = "select * from order_table where ordered_date between '" + from + "' and  '" + end + "'";
		pst = JdbcConnection.getConnection().prepareStatement(mothlyBill);
		rst = pst.executeQuery();
		System.out.println("ItemNo\tItemName\tItemPrice\tTotalAmount");
		while (rst.next()) {
			System.out
					.println(rst.getInt(1) + "\t" + rst.getString(2) + "\t\t" + rst.getInt(3) + "\t\t" + rst.getInt(4));
		}
		String mothlyBill1 = "select sum(totalamt) from order_table where ordered_date between '" + from + "' and  '"
				+ end + "'";
		pst = JdbcConnection.getConnection().prepareStatement(mothlyBill1);
		rst = pst.executeQuery();
		rst.next();
		int amt = rst.getInt(1);
		System.out.println("TOTAL TODAY COLLECTION IS: " + amt + "Rs");
	}
}
