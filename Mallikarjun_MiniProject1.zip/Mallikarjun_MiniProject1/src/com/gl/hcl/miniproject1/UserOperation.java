package com.gl.hcl.miniproject1;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class UserOperation {
	static PreparedStatement pst = null;
	static ResultSet rst = null;
	static int item_no;
	static int order_no;
	static Date ordered_date;
	static int ordered_quantity;
	static Scanner sc = new Scanner(System.in);
	static String userName;
	static int userId;
	static String userEmailId;
	static String password;
	static String mobileNo;

	public static void userRegistration() {
		System.out.println("Enter the user name: ");
		userName = sc.next();

		System.out.println("Enter the user Id: ");
		userId = sc.nextInt();

		System.out.println("Enter the emailId: ");
		userEmailId = sc.next();

		System.out.println("Enter the password: ");
		password = sc.next();

		System.out.println("Enter the mobile no: ");
		mobileNo = sc.next();

	}

	public static void userLogin() throws ExceptionHandling {
		System.out.println("Enter the user name: ");
		String auname = sc.next();
		System.out.println("Enter the password: ");
		String apass = sc.next();
		if (auname.equalsIgnoreCase(userName) && apass.equalsIgnoreCase(password)) {
			System.out.println("login successful...");
		} else {
			throw new ExceptionHandling("incorrecct username or password...");
		}

	}

	public static void order() throws SQLException {
		while (true) {
			System.out.println("Items List");
			String itemsDisp = "select * from ItemMenu";
			pst = JdbcConnection.getConnection().prepareStatement(itemsDisp);
			rst = pst.executeQuery();
			System.out.println("ItemNo\tItemName\tItemPrice");
			while (rst.next()) {
				System.out.println(rst.getInt(1) + "\t" + rst.getString(2) + "\t\t" + rst.getInt(3));
			}
			System.out.println("Enter the item number: ");
			item_no = sc.nextInt();
			System.out.println("Enter the order number: ");
			order_no = sc.nextInt();
			ordered_date = DataClass.localDateTimeApi();
			System.out.println("Enter the ordered_quantity");
			ordered_quantity = sc.nextInt();
			String getPrice = "select item_price from ItemMenu where item_no=?";
			pst = JdbcConnection.getConnection().prepareStatement(getPrice);
			pst.setInt(1, item_no);
			rst = pst.executeQuery();
			rst.next();
			int price = rst.getInt(1);
			int total = price * ordered_quantity;
			String order = "insert into order_table values(?,?,?,?,?)";
			pst = JdbcConnection.getConnection().prepareStatement(order);
			pst.setInt(1, order_no);
			pst.setDate(2, ordered_date);
			pst.setInt(3, ordered_quantity);
			pst.setInt(4, total);
			pst.setInt(5, item_no);
			int i = pst.executeUpdate();
			if (i > 0) {
				System.out.println("Item is inserted Successfully....");
			} else {
				System.out.println("Item is not inserted...");
			}
			System.out.println("do you want to continue the order process...yes/no");
			String in1 = sc.next();
			if (in1.equalsIgnoreCase("no")) {
				break;
			}
		}

	}

	public static void billScreen() throws SQLException {
		System.out.println("Enter the order number: ");
		order_no = sc.nextInt();
		String billScreen = "select * from order_table where order_no=?";
		pst = JdbcConnection.getConnection().prepareStatement(billScreen);
		pst.setInt(1, order_no);
		rst = pst.executeQuery();
		while (rst.next()) {
			System.out.println("OrderNo: " + rst.getInt(1) + "\t" + "OrderedDate: " + rst.getString(2) + "\t"
					+ "OrderedQuantity: " + rst.getInt(3) + "\t" + "ItemAmount: " + rst.getInt(4) + "\t" + "Item No: "
					+ rst.getInt(5) + "\t");
		}
		String itemInfo = "select item_no from order_table where order_no=?";
		pst = JdbcConnection.getConnection().prepareStatement(itemInfo);
		pst.setInt(1, order_no);
		rst = pst.executeQuery();

		while (rst.next()) {
			int k = 1;
			int i = rst.getInt(k);
			String itemInfo1 = "select * from ItemMenu where item_no =?";
			pst = JdbcConnection.getConnection().prepareStatement(itemInfo1);
			pst.setInt(1, i);
			rst = pst.executeQuery();
			while (rst.next()) {
				System.out.println("Item name: " + rst.getString(2) + "\t" + "Item price: " + rst.getInt(3));
				k++;
			}

		}
		String itemInfo2 = "select sum(totalamt) from order_table where order_no =?";
		pst = JdbcConnection.getConnection().prepareStatement(itemInfo2);
		pst.setInt(1, order_no);
		rst = pst.executeQuery();
		rst.next();

		System.out.println("Total amount: " + rst.getInt(1));

	}
}
