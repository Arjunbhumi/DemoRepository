package com.gl.hcl.miniproject1;

import java.sql.Date;
import java.time.LocalDate;

public class DataClass {

	public static Date localDateTimeApi() {
		LocalDate d = LocalDate.now();

		Date date = Date.valueOf(d);

		return date;

	}
}
