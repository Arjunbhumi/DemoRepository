package com.gl.hcl.miniproject1;

import java.sql.Connection;
import java.sql.DriverManager;

public class JdbcConnection {
	// here i am creating common database connection class

	// here i am creating the getconnection method it will return the connection
	public static Connection getConnection() {
		// this help us to register our class as a driver class
		String driver = "com.mysql.cj.jdbc.Driver";
		// this provides path to connect the database
		String url = "jdbc:mysql://localhost:3306/Abhiruchi_Restaurent";
		// this is the user name for data base
		String username = "root";
		// this is the pass word for data base
		String password = "root";
		Connection con = null;
		try {
			// here the for name method load our driver dynamically
			Class.forName(driver);
			// drivermanager establish the connection
			con = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

}
