create database Abhiruchi_Restaurent;
drop database Abhiruchi_Restaurent;
use Abhiruchi_Restaurent;

create table ItemMenu (item_no int(8) primary key,item_name varchar(30)not null,item_price int(6) not null);
desc ItemMenu;
insert into ItemMenu values(101,"puri",10);
insert into ItemMenu values(102,"Dosa",60);
insert into ItemMenu values(103,"idly",250);
insert into ItemMenu values(104,"tea",25);
insert into ItemMenu values(105,"pongal",20);
select * from ItemMenu;
create table order_table (order_no int(6) not null,ordered_date date not null,ordered_quantity int(5) not null,totalamt int(5) not null,item_no int(5) not null,foreign key (item_no) references items_table(item_no));


